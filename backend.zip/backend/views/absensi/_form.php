<?php

use backend\models\MasterKode;
use kartik\select2\Select2;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var backend\models\Absensi $model */
/** @var yii\widgets\ActiveForm $form */
$pathInfo = Yii::$app->request->getPathInfo();

?>

<div class="absensi-form table-container">

    <?php $form = ActiveForm::begin(); ?>

    <div class="row">


        <?php $id_karyawan = Yii::$app->request->get('id_karyawan'); ?>
        <?php $tanggal = Yii::$app->request->get('tanggal'); ?>
        <?= $form->field($model, 'id_karyawan')->hiddenInput(['value' => $id_karyawan ?? $model->id_karyawan])->label(false) ?>
        <?= $form->field($model, 'tanggal')->hiddenInput(['value' => $tanggal])->label(false) ?>

        <?php if ($pathInfo == 'absensi/update') : ?>
            <div class="col-md-6">
                <?= $form->field($model, 'jam_masuk')->textInput(['readonly' => true, 'disabled' => true, 'type' => 'time',]) ?>
            </div>
        <?php else : ?>
            <div class="col-md-6">
                <?= $form->field($model, 'jam_masuk')->textInput(['type' => 'time', 'value' => '08:00']) ?>
            </div>
        <?php endif; ?>


        <?php if ($pathInfo == 'absensi/create') : ?>
            <div class="col-md-6">
                <?= $form->field($model, 'jam_pulang')->textInput(['readonly' => true, 'disabled' => true, 'type' => 'time',]) ?>
            </div>
        <?php else : ?>
            <div class="col-md-6">
                <?= $form->field($model, 'jam_pulang')->textInput(['type' => 'time', 'value' => '17:00']) ?>
            </div>
        <?php endif; ?>


        <?php if ($pathInfo == 'absensi/create') : ?>
            <div class="col-12">
                <?php
                $data = \yii\helpers\ArrayHelper::map(MasterKode::find()->where(['nama_group' => Yii::$app->params['status-hadir']])->andWhere(['!=', 'status', 0])->orderBy(['urutan' => SORT_ASC])->all(), 'kode', 'nama_kode');
                echo $form->field($model, 'kode_status_hadir')->widget(Select2::classname(), [
                    'data' => $data,
                    'language' => 'id',
                    'options' => ['placeholder' => 'Pilih Status Kehadiran ...'],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                ])->label('Status Hadir');
                ?>
            </div>
        <?php else : ?>
            <div class="col-12">
                <?php
                $data = \yii\helpers\ArrayHelper::map(MasterKode::find()->where(['nama_group' => Yii::$app->params['status-hadir']])->andWhere(['!=', 'status', 0])->orderBy(['urutan' => SORT_ASC])->all(), 'kode', 'nama_kode');
                echo $form->field($model, 'kode_status_hadir')->widget(Select2::classname(), [
                    'data' => $data,
                    'language' => 'id',
                    'options' => ['placeholder' => 'Pilih Status Kehadiran ...'],
                    'pluginOptions' => [
                        'allowClear' => true
                    ],
                    'disabled' => true,
                    'readonly' => true
                ])->label('Status Hadir');
                ?>
            </div>

        <?php endif; ?>

        <div class="col-md-6">
            <?= $form->field($model, 'keterangan')->textarea(['rows' => 1, 'maxlength' => true, "class" => "form-control", "placeholder" => "Keterangan Berhalangan Hadir"]) ?>
            <p style="margin-top: -15px; font-size: 14.5px;" class="text-capitalize  text-muted"> Keterangan Jika berhalangan hadir</p>
        </div>
        <div class="col-md-6">
            <?= $form->field($model, 'lampiran')->textInput(["placeholder" => "Lampiran", "class" => "form-control", 'type' => 'file'])->label('Lampiran') ?>
            <p style="margin-top: -15px; font-size: 14.5px;" class="text-capitalize  text-muted"> lampiran Jika berhalangan hadir</p>
        </div>


    </div>


    <div class="form-group">
        <button class="add-button" type="submit">
            <span>
                Save
            </span>
        </button>
    </div>

    <?php ActiveForm::end(); ?>

</div>