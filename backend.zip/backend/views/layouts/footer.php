<footer class="main-footer text-center">
    <strong>Copyright &copy; 2024 Profaskes.id</a>.
</footer>