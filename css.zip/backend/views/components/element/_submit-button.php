<button class="disabled:bg-gray-500 flex justify-center add-button w-full text-center " type="submit">
    <p class="py-1 text-center text-[15px]">
        <?= $text ?>
    </p>
</button>