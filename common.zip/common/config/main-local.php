<?php

return [
    'components' => [
        'db' => [
            'class' => \yii\db\Connection::class,
            'dsn' => 'mysql:host=localhost;dbname=profas_payroll',
            'username' => 'profas_user_payroll',
            'password' => 'PayrollSystem2024!!',
            'charset' => 'utf8',
        ],
        'mailer' => [
            //'class' => 'yii\swiftmailer\Mailer',
            'class' => \yii\symfonymailer\Mailer::class,
            'messageClass' => 'yii\symfonymailer\Message',
            'transport' => [
                'scheme' => 'smtps',
                'host' => 'mail.profaskes.id',
                'username' => 'account@profaskes.id',
                'password' => 'Profaskes!@#$%^',
                'port' => '465',
                'options' => [
                    'ssl' => true
                ],

            ],
            'messageConfig' => [
                'from' => ['account@profaskes.id' => 'PROFASKES SOFTECH INDONESIA'], // this is needed for sending emails
                'charset' => 'UTF-8',
            ],
            'useFileTransport' => false, //jadikan false jika ingin bisa kirim email
            'viewPath' => '@app/mail',
        ],
    ],
];
